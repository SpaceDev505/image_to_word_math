# mathpx

OCR for mathematical equations
